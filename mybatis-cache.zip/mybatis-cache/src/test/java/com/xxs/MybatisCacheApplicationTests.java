package com.xxs;

import cn.hutool.json.JSONUtil;
import com.xxs.dao.SysUserExtMapper;
import com.xxs.dao.SysUserMapper;
import com.xxs.entity.SysUser;
import com.xxs.vo.SysUserExtVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@SpringBootTest(classes = MybatisCacheApplication.class)
@RunWith(SpringRunner.class)
class MybatisCacheApplicationTests {

    @Autowired
    @Qualifier("mySqlSessionFactory")
    private SqlSessionFactory sqlSessionFactory;

    /**
     * 测试一级缓存在单个sqlSession中生效
     */
    @Test
    void firstLevelCache() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        SysUserMapper mapper = sqlSession.getMapper(SysUserMapper.class);
        SysUser sysUser1 = mapper.selectById(1L);
        log.info("第一次查询={}", JSONUtil.toJsonStr(sysUser1));

        // commit、update(insert、update、delete)操作会使得一级缓存失效
        // sqlSession.commit();

        SysUser sysUser2 = mapper.selectById(1L);
        log.info("第二次查询={}", JSONUtil.toJsonStr(sysUser2));
    }

    /**
     * 开启二级缓存
     * 测试二级缓存在一个或多个sqlSession中生效
     */
    @Test
    void secondLevelCache() {
        SqlSession sqlSession1 = sqlSessionFactory.openSession();
        SysUserMapper mapper1 = sqlSession1.getMapper(SysUserMapper.class);
        SysUser sysUser1 = mapper1.selectById(1L);
        log.info("第一次查询={}", JSONUtil.toJsonStr(sysUser1));
        /**
         * commit可以清除一级缓存、生效二级缓存
         * 如果不提交，此case既无法使用二级缓存、也无法使用一级缓存
         */
        //sqlSession1.commit();
        SqlSession sqlSession2 = sqlSessionFactory.openSession();
        SysUserMapper mapper2 = sqlSession2.getMapper(SysUserMapper.class);
        SysUser sysUser2 = mapper2.selectById(1L);
        log.info("第二次查询={}", JSONUtil.toJsonStr(sysUser2));
    }

    /**
     * 关闭二级缓存、开启一级缓存
     * 测试一级缓存在多个sqlSession下脏读（即不在多个sqlSession中共享）
     * 缓存、sqlSession都是隔离的，一个sqlSession的修改对其它应用的查询缓存不可见
     */
    @Test
    void firstLevelCacheDirty() {
        SqlSession sqlSession1 = sqlSessionFactory.openSession();// 默认打开的都是【非自动提交】
        SysUserMapper mapper1 = sqlSession1.getMapper(SysUserMapper.class);
        SysUser sysUser1 = mapper1.selectById(1L);
        log.info("第一次查询={}", JSONUtil.toJsonStr(sysUser1));

        SqlSession sqlSession2 = sqlSessionFactory.openSession();
        SysUserMapper mapper2 = sqlSession2.getMapper(SysUserMapper.class);
        SysUser sysUser2 = mapper2.selectById(1L);
        log.info("第二次查询={}", JSONUtil.toJsonStr(sysUser2));

        mapper2.updateName(1L, "pwj1");
        sqlSession2.commit();// jdbc事务管理器需要手动提交

        SysUser sysUser3 = mapper1.selectById(1L);
        log.info("第三次查询={}", JSONUtil.toJsonStr(sysUser3));
    }

    /**
     * mapper关联查询时，会发生问题
     * 解决方法：在SysUserExtMapper.xml中配置<cache-ref namespace="com.xxs.dao.SysUserMapper"/>关联SysUserMapper的缓存
     */
    @Test
    void secondLevelCacheDirty() {
        SqlSession sqlSession1 = sqlSessionFactory.openSession();// 默认打开的都是【非自动提交】
        SysUserMapper sysUserMapper = sqlSession1.getMapper(SysUserMapper.class);
        SysUser sysUser = sysUserMapper.selectById(1L);
        log.info("查询sys_user={}", JSONUtil.toJsonStr(sysUser));

        SysUserExtMapper sysUserExtMapper = sqlSession1.getMapper(SysUserExtMapper.class);
        SysUserExtVO sysUserExtVO1 = sysUserExtMapper.selectByUserId(1L);
        log.info("查询sys_usr_ext={}", JSONUtil.toJsonStr(sysUserExtVO1));

        /**
         * 此时sysUserMapper缓存被刷新了，但是sysUserExtMapper的缓存仍在
         */
        sysUserMapper.updateName(1L, "pwj5");
        sqlSession1.commit();

        SysUserExtVO sysUserExtVO2 = sysUserExtMapper.selectByUserId(1L);
        log.info("再次查询sys_usr_ext={}", JSONUtil.toJsonStr(sysUserExtVO2));
    }
}