package com.xxs.dao;

import com.xxs.entity.SysUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Entity generate..SysUser
 */
public interface SysUserMapper {

    SysUser selectById(@Param("id") Long id);

    void addSysUser(@Param("sysUser") SysUser sysUser);

    void updateName(@Param("id") Long id, @Param("name") String name);
}