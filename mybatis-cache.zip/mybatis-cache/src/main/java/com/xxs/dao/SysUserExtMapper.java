package com.xxs.dao;

import com.xxs.vo.SysUserExtVO;
import org.apache.ibatis.annotations.Param;

public interface SysUserExtMapper {
    SysUserExtVO selectByUserId(@Param("userId") Long userId);
}
