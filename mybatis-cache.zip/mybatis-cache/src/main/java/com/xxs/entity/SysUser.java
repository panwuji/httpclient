package com.xxs.entity;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 系统用户表
 * @TableName sys_user
 */
@Data
public class SysUser implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 姓名
     */
    private String name;

    /**
     * 密码
     */
    private String password;

    /**
     * 状态（0 删除 1 正常）
     */
    private Byte status;

    /**
     * 创建时间
     */
    private Date crtTime;

    /**
     * 更新时间
     */
    private Date uptTime;

    private static final long serialVersionUID = 1L;
}