package com.xxs.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SysUserExt implements Serializable {
    private Long id;

    private Long userId;

    private String address;

    private String phone;

    private Date crtTime;

    private Date uptTime;
}
