package com.xxs.service;

import cn.hutool.json.JSONUtil;
import com.xxs.dao.SysUserMapper;
import com.xxs.entity.SysUser;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.util.Objects;

/**
 *
 */
@Slf4j
@Service
public class SysUserServiceImpl implements SysUserService{

    @Autowired
    private SysUserMapper sysUserMapper;

    @Autowired
    @Qualifier("mySqlSessionFactory")
    private SqlSessionFactory sqlSessionFactory;

    @Override
    public SysUser getUserById(Long id) {
        //return sysUserMapper.selectById(id);

        SqlSession session1 = null;
        SqlSession session2 = null;
        try {
            session1 = sqlSessionFactory.openSession();
            session2 = sqlSessionFactory.openSession();
            SysUserMapper mapper1 = session1.getMapper(SysUserMapper.class);
            SysUser sysUser1 = mapper1.selectById(id);
            log.info("第一次查询用户={}", JSONUtil.toJsonStr(sysUser1));
            session1.commit();
            SysUserMapper mapper2 = session2.getMapper(SysUserMapper.class);
            SysUser sysUser2 = mapper2.selectById(id);
            log.info("第二次查询用户={}", JSONUtil.toJsonStr(sysUser2));
            return sysUser1;
        } catch (Exception e) {
            log.error("catch error={}", e);
        } finally {
            if (Objects.nonNull(session1)) {
                session1.close();
            }
            if (Objects.nonNull(session2)) {
                session2.close();
            }
        }
        return null;
    }

    @Override
    public SysUser addSysUser(SysUser sysUser) {
        SqlSession session = null;
        try {
            session = sqlSessionFactory.openSession(false);
//            Connection connection = session.getConnection();
//            connection.setAutoCommit(false);
            SysUserMapper mapper = session.getMapper(SysUserMapper.class);
            mapper.addSysUser(sysUser);
            //session.rollback();
            session.commit();
            return sysUser;
        } catch (Exception e) {
            log.error("catch error={}", e);
        } finally {
            if (Objects.nonNull(session)) {
                session.close();
            }
        }
        return null;
    }
}