package com.xxs.service;

import com.xxs.entity.SysUser;

/**
 *
 */
public interface SysUserService {

    SysUser getUserById(Long id);

    SysUser addSysUser(SysUser sysUser);
}