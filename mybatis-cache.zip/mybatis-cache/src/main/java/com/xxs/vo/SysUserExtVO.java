package com.xxs.vo;

import com.xxs.entity.SysUserExt;
import lombok.Data;

import java.io.Serializable;

@Data
public class SysUserExtVO extends SysUserExt implements Serializable {

    private String name;
}
