package com.xxs.config;

import cn.hutool.json.JSONUtil;
import com.alibaba.druid.pool.DruidDataSource;
import com.xxs.dao.SysUserMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.LocalCacheScope;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScannerRegistrar;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.mybatis.spring.transaction.SpringManagedTransactionFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import javax.sql.DataSource;

@Slf4j
@org.springframework.context.annotation.Configuration
public class MybatisConfiguration {

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDefaultAutoCommit(false);
        log.info("datasource info={}", JSONUtil.toJsonStr(dataSource));
        return dataSource;
    }

//    @Bean("mySqlSessionFactory")
//    public SqlSessionFactory sqlSessionFactory() throws Exception {
//        TransactionFactory transactionFactory = new JdbcTransactionFactory();
//        Environment environment = new Environment("development", transactionFactory, dataSource());
//        Configuration configuration = new Configuration(environment);
//        configuration.setLocalCacheScope(LocalCacheScope.SESSION);
//        configuration.setCacheEnabled(Boolean.TRUE);
//        //configuration.setCacheEnabled(Boolean.FALSE);
//        configuration.addMapper(SysUserMapper.class);
//        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(configuration);
//        return sqlSessionFactory;
//    }


    @Bean("mySqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        //SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        //sqlSessionFactoryBean.setDataSource(dataSource());//数据源
        //sqlSessionFactoryBean.setTypeAliasesPackage("com.xxs.entity");//实体类
        //ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        //sqlSessionFactoryBean.setMapperLocations(resolver.getResources("classpath:mapper/*.xml"));//mapper.xml
        //SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBean.getObject();
        //sqlSessionFactory.getConfiguration().setLocalCacheScope(LocalCacheScope.SESSION);
        //return sqlSessionFactory;

        Configuration configuration = new Configuration();
        configuration.setLocalCacheScope(LocalCacheScope.STATEMENT);
        configuration.setCacheEnabled(true);

        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setConfiguration(configuration);
        sqlSessionFactoryBean.setDataSource(dataSource());//数据源
        sqlSessionFactoryBean.setTypeAliasesPackage("com.xxs.entity");//实体类
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        sqlSessionFactoryBean.setMapperLocations(resolver.getResources("classpath:com/xxs/dao/*.xml"));//mapper.xml
        //sqlSessionFactoryBean.setTransactionFactory(new JdbcTransactionFactory());
        //sqlSessionFactoryBean.setTransactionFactory(new SpringManagedTransactionFactory());//不设置时，默认

        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBean.getObject();

        log.info("mybatis一级缓存配置={}", sqlSessionFactory.getConfiguration().getLocalCacheScope());
        log.info("mybatis二级缓存配置={}", sqlSessionFactory.getConfiguration().isCacheEnabled());

        return sqlSessionFactory;
    }

//    @Bean
//    public PlatformTransactionManager transactionManager() {
//        return new JdbcTransactionManager(dataSource());
//    }
}